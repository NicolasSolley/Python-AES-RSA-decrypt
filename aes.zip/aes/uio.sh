var="9101797ba6c53445ac4b703038ffd449"
echo "hash: $var"
echo
echo "Checking for matching hash file..."
md5 *.eaes | grep "9101797ba6c53445ac4b703038ffd449"

